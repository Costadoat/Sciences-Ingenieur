import numpy as np
import pint
import matplotlib.pyplot as plt

u = pint.UnitRegistry()

def print_var(name: str, unit=None):
    var = globals()[name].to_reduced_units()
    if unit is not None:
        var.ito(unit)
    print(f'{name} = {var:~P}')

#%% Question 3
v = 1.2 * u.m/u.s
cad = 85 * 1/u.min
L_pas = v/cad

print_var('L_pas')

#%% Question 4
T_cycle = 1/cad

print_var('T_cycle', u.s)

#%% Question 9
H = 1.75 * u.m
L1 = 0.530 * H
L2 = L1
L4 = 0.152 * H

theta_flex_max = np.arccos(-(L4-0.5*L_pas)/np.sqrt((L1+L2)**2+L4**2)) - np.arctan((L1+L2)/L4)
theta_flex_max_corr = 2*np.arctan(2*(L1+L2-np.sqrt((L1+L2)**2+L_pas*L4-1/4*L_pas**2))/(L_pas-4*L4))

print_var('L1')
print_var('L4')
print_var('theta_flex_max', u.deg)
print_var('theta_flex_max_corr', u.deg)

#%% Question 26
M = 70 * u.kg
m = M * (0.1000 + 0.0465 + 0.0145)

print_var('m')

#%% Question 27
k_red = (2/7)**3
C_max_kg = 1.6 * u.N * u.m / u.kg
C_max = C_max_kg * m
C_m_max = C_max * k_red

print_var('C_max')
print_var('C_m_max', u.mN * u.m)

#%% Question 37
R_t = 37.5 * u.mm
i_r = 66
eta_c = 0.95
eta_r = 0.72
M_m_max = 240 * u.mN * u.m
Delta_F_amp = M_m_max * i_r * eta_c * eta_r / R_t

print_var('Delta_F_amp', u.N)

#%% Question 38
F_T_0 = 480 * u.N
F_T_amp = 200 * u.N
F_R_amp = Delta_F_amp - F_T_amp
F_R_min = F_T_0 - F_R_amp
F_R_max = F_T_0 + F_R_amp

print_var('F_R_amp', u.N)
print_var('F_R_min', u.N)
print_var('F_R_max', u.N)

#%% Question 44
a = 500 * u.N / u.s
K0 = 133.1 * u.ms
epsilon_t = a*K0

print_var('epsilon_t')

#%% Question 46
T = 0.5 * u.s
omega = 2*np.pi / T

Y_amp = 25 * u.mm
m_b_max = 135 * u.kg
m_s = 3 * u.kg
a_y_max = Y_amp * omega**2
g = 9.81 * u.m / u.s**2
F_t_max1 = (m_s + 0.5*m_b_max) * (Y_amp * omega**2 + g)
F_t_max2 = (m_s + 1*m_b_max) * (Y_amp * omega**2 + g)

print_var('omega', u.rad/u.s)
print_var('F_t_max1', u.kN)
print_var('F_t_max2', u.kN)

#%% Question 50
s = 2e-3
U_alim = 10 * u.V
F_t_max = 1 * u.kN
F_t = 950 * u.N
U_capteur = s*U_alim/F_t_max * F_t

print_var('U_capteur', u.mV)

#%% Question 54
rho = 0.0178 * u.Ω * u.mm**2 / u.m
L = 2 * u.m
d = 3 * u.mm
S = np.pi * d**2 / 4
R = rho*L/S

print_var('R', u.mΩ)

#%% Question 55
L = 0.329 * u.mH
R = 1.13 * u.Ω
tau_m = 4.28 * u.ms
tau_e = L/R
omega_m = 1/tau_m
omega_e = 1/tau_e

print_var('tau_e', u.ms)
print_var('omega_m', u.rad/u.s)
print_var('omega_e', u.rad/u.s)

#%% Question 62
t = np.linspace(0, 1, 1000)
i = 1 - np.exp(-t/0.2)

plt.figure()
plt.plot(t, i)
plt.plot([0, 0.2], [0, 1], color=[0.5,0.5,0.5], linewidth=1)

plt.xlim([0, 1])
plt.ylim([0, 1.2])

plt.grid()
plt.xticks([0, 0.2], ['0', r'$\tau_e$'])
plt.yticks([0, 1], ['0', r'$I_\infty$'])

plt.xlabel(r'Temps $t$')
plt.ylabel(r'Courant $i(t)$')
plt.tight_layout()

#%% Question 64
omega = np.exp(-t/0.2)

plt.figure()
plt.plot(t, omega)
plt.plot([0, 0.2], [1, 0], color=[0.5,0.5,0.5], linewidth=1)

plt.xlim([0, 1])
plt.ylim([0, 1.2])

plt.grid()
plt.xticks([0, 0.2], ['0', r'$\tau_m$'])
plt.yticks([0, 1], ['0', r'$\omega_0$'])

plt.xlabel(r'Temps $t$')
plt.ylabel(r'Vitess de rotation $\omega(t)$')
plt.tight_layout()
