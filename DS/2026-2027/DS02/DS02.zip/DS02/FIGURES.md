# Correspondance des figures de DS02.tex (dossier img/, format PNG)

fig01 à fig39 : même numéro que la « Figure N » du sujet Banque PT 2024.
fig01–fig20 sont déjà fournies (extraites à 300 dpi). Restent à faire : fig21 à fig49.

## Figures du sujet (à extraire)
fig21 vue annotée structure ciseaux      fig22 schéma cinématique ciseaux
fig23 schéma cinématique du module       fig24 schéma isostatique plan
fig25 schéma simplifié (partie III)      fig26 vue annotée d'une penture (plan médian)
fig27 schéma partiel G_P1 / G_P2         fig28 motorisation d'une plateforme
fig29 schéma-blocs un moteur             fig30 schéma-blocs deux moteurs
fig31 asservissement en position         fig32 modèle simplifié du moteur
fig33 saturation (schéma-blocs)          fig34 simulation (2 courbes : dézoomée + zoom)
fig35 annexe A (2 coupes de la salle)    fig36 annexe B1 dessin d'ensemble de la penture
fig37 vérin Spiralift (vue 3D)           fig38 vérin Spiralift (vue 3D en coupe)
fig39 détail liaison tige de vérin / plateforme

## Supports du cahier réponses (sans numéro de figure dans le sujet)
fig40 Q1  : deux rangs (i+1 et i) avec les positions du siège pendant la rotation (cote 1300)
fig41 Q5  : DÉTAIL C et DÉTAIL E (vues en coupe, côte à côte)
fig42 Q6  : schéma cinématique partiel 3D à compléter (3, P2, P1, 0)
fig43 Q18 : schéma cinématique partiel de la penture (A, B, C, P1, P2, 3, 0)
fig44 Q40 : grilles de Bode vierges (gain et phase)

## Figures du corrigé
fig45 Q1  : tracé corrigé (lignes rouges)
fig46 Q6  : schéma 3D complété (huit sphériques)
fig47 Q7  : schéma cinématique minimal 2D (A, B, C)
fig48 Q18 : directions (AB) et (BC) tracées
fig49 Q40-41 : Bode asymptotique + courbes réelles
