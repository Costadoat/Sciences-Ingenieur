import matplotlib.pyplot as plt
import numpy as np

file=open('data.csv','r')
contenu=file.read()
lignes=contenu.split('\n')

xexp = []
yexp = []
for ligne in lignes[1:-1]:
    data=ligne.split(';')
    xexp.append(float(data[0]))
    yexp.append(float(data[1]))

# Resultats expérimentaux, texp, yexp et yErrorexp doivent avoir la même taille
xexprl=np.array(xexp).reshape(len(xexp),1)
yexprl=np.array(yexp).reshape(len(yexp),1)

# Si l'incertitude est calculée à partir d'un poucentage de la valeur
pourcent=10
yErrorexp = [pourcent*i/100 for i in yexp]

x=np.array(xexp)
K=10
tau=0.01
ymod=K*(1-np.exp(-x/tau))

# Tracé
plt.title("Modélisation")
plt.xlabel('Temps (t)')
plt.ylabel('Gradeur (unité)')
plt.plot(x, ymod, zorder = 1)
plt.grid('on')
plt.scatter(xexp, yexp, zorder = 2)
plt.errorbar(xexp, yexp, yerr = yErrorexp, fmt='none', capsize = 10, ecolor = 'red', zorder = 1)
plt.show()
